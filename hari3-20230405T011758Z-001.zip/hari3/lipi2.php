<?php
    $age = array("Made"=>"19", "Mayada"=>"20", "Tresna"=>"21", "Yoga"=>"22");

    echo "Umur dari Made ",$age["Made"], " tahun<br> ";


    echo "<hr>";

    foreach($age as $nama => $umur){
        echo "Umur dari " . $nama ." : " . $umur . "<br>" ;
    }
 
