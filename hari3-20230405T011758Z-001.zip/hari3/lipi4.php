<?php


    function tentangaplikasi(){
        echo "<h3>aplikasi apasaja</h3>";
        echo "<sup>versi 1.0</sup>";
    }

    function cetaklabel01($tx){
        echo "isi label:" .$tx

    }
    