<?php

    $cars = array("Civic","BMW","Lamborgini","Mustang");

    $jmldata = count($cars);
    echo " Jumlah Data ", $jmldata , "<br>";
    for($i=0;$i<$jmldata;$i++){
        echo "<br>Kendaraan ", $cars[$i];
    }

    echo "<hr>";

    echo "<ol>";
    foreach($cars as $dta){
        echo "<li>Kendaraan " , $dta , "</li>" ;
    }
    echo "</ol>";
