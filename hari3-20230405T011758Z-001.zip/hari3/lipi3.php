<?php

    $mhs = array(
        array("NAMA"=> "Boboiboy","ID"=>"1234","KOTA"=>"Pulau Rintis"), 
        array("NAMA"=> "Upin","ID"=>"1235","KOTA"=>"Durian Runtuh"),
        array("NAMA"=> "Ipin","ID"=>"1236","KOTA"=>"Runtuh Durian"), 
        array("NAMA"=> "Ejen ALi","ID"=>"1237","KOTA"=>"Kota Cyberaya"), 
        array("NAMA"=> "Adit","ID"=>"1238","KOTA"=>"Jakarta"),
    );

    // echo $mhs[0]["NAMA"];
    // echo "<hr>";
    // print_r($mhs);
    // echo "<hr>";

    // foreach($mhs as $dta){

    //     foreach ($dta as $lb => $nval){
    //         echo $lb. ":" .$nval. "<br>";
    //     }
    //         echo "<br>";

        



    // }

    header("content-type: application/jason");
    echo json_encode($mhs);






    